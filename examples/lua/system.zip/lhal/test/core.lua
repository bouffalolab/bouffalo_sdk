local core = require("core")

local gpio_dev = core.get("gpio")

print(gpio_dev)
print(gpio_dev.name)
print(gpio_dev.reg_base)
print(gpio_dev.irq_num)
print(gpio_dev.idx)
print(gpio_dev.sub_idx)
print(gpio_dev.dev_type)
print(gpio_dev.user_data)
