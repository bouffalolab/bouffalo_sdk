local gpio = require("gpio")
local core = require("core")
local mtimer = require("mtimer")

local bank = core.get("gpio")

gpio.init(bank, 2, gpio.OUT | gpio.PU | gpio.SMT1 | gpio.DRV0)

while(true)
do
    gpio.set(bank, 2)
    print("gpio 2 set")
    mtimer.delay_ms(200)
    gpio.reset(bank, 2)
    print("gpio 2 reset")
    mtimer.delay_ms(200)

end