local test_path = "sd:/system/lhal/test/gpio.lua"
local f = assert(loadfile(test_path))
local ret = f()
